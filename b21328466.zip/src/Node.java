public class Node {
    int key;
    int level;
    Node left, right;

    public Node(int item, int level) {
        key = item;
        this.level = level;
        left = right = null;
    }
}